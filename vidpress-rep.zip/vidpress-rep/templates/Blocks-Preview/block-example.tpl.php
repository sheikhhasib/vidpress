<?php $img_path = ST_URL . "/templates/Blocks-Preview/assets/$handle.jpg"; ?>
<div class="w-block-example">
  <img src="<?php echo $img_path; ?>" alt="<?php echo $handle; ?>">
</div>
