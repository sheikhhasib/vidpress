<?php
/**
 *  Provides Wordpress Backend Capability like any dashboard setting
 */

namespace VidPress;

class Admin {

}
