<?php
/**
 * Frontend related functionalities widgets filter etc
 */
namespace VidPress;

class Frontend {

}
