<?php

namespace VidPress;


/**
 * Ajax handler class
 */
class Ajax {

}
